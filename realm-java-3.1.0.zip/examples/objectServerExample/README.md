# Using this example

This example shows a minimal example on how to connect to and use the
Realm Object Server to synchronize changes between devices.

The example will assume that the Object Server is running on the machine
building the example and the IP address will automatically be injected
into the build configuration.

If this for some reasons does not work, please insert the IP Address into
the `build.gradle` accordingly.

To read more about the Realm Object Server and how to deploy it, see
https://realm.io/news/introducing-realm-mobile-platform/
